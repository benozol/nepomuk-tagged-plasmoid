from PyQt4 import Qt

class TaggedResourcesQmlPlugin(Qt.QDeclarativeExtensionPlugin):
    def registerTypes(uri):
